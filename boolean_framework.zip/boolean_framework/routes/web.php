<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/user/verify/{token}', 'Auth\RegisterController@verifyUser')->name('user/verify');

Route::get('/', function () {
    $data = [];
    $data['welcome_name'] = 'Boolean';
    return view('welcome',$data);
});

Route::get('/about', function () {
    return view('others/about' );
 });
 
 Route::get('/contact', function () {
     return view('others/contact');
 });
 
 Route::get('/ourGoal', function () {
     return view('others/ourGoal');
 });

 Route::get('send_test_email', function(){
	Mail::raw('Sending emails with Mailgun and Laravel is easy!', function($message)
	{
		$message->to('bootolean@gmail.com');
	});
});

 Auth::routes();

Route::middleware('auth')->group(function(){
    Route::post('/home', 'HomeController@index')->name('home');
    Route::get('/home', 'HomeController@index')->name('home');

    Route::get('/users', 'HomeController@userAction')->name('users');
    Route::post('/users', 'HomeController@userAction')->name('users');

    Route::get('/userTypeOps', 'HomeController@userTypeOps')->name('userTypeOps');
    Route::post('/userTypeOps', 'HomeController@userTypeOps')->name('userTypeOps');
    Route::post('/userTypeUpdate', 'HomeController@userTypeUpdate')->name('userTypeUpdate');

});
