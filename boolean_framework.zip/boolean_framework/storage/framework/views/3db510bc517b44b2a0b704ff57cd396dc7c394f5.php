<style>
             .content {
                text-align: center;
            }
    
            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none !important;
                text-transform: uppercase;
            }
            .title {
                font-size: 35px;
            }
       
        </style>
<?php $__env->startSection('content'); ?>
<div class="container">
   
            <div class="card">
                <div class="card-header"><?php echo e(__('Contact Us')); ?></div>

                <div class="card-body">
                <div class="title m-b-md">
                HOW TO REACH BOO
                </div>
                <h4>Small Business</h4>
                <p>+1717-982-0481</p>
                <h4>Mid- and Large Business</h4>
                <p>+1717-982-0481</p>               
                </div>
                <div class="card-footer">
                <div class="content">
                <div class="links">
                    <a href="<?php echo e(url('/about')); ?>">About</a>
                    <a href="<?php echo e(url('/contact')); ?>">Contact</a>
                    <a href="<?php echo e(url('/ourGoal')); ?>">Our goal</a>                  
                </div>
                </div>
                </div>
         
    </div>

   
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\cygwin64\home\u783206\boolean_framework\resources\views/others/contact.blade.php ENDPATH**/ ?>