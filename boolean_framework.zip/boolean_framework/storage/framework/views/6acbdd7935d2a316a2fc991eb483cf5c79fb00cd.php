<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
        
        <div class="card-header"><?php echo e($modify == 1 ? 'Modify User Type' : 'User Type Information'); ?></div>
        <div class="card-body">
        <a class="btn btn-primary" href="<?php echo e(url('/users')); ?>">Back</a>     
        <form action="<?php echo e($modify == 1 ? route('userTypeOps', [ 'userTypeID' => $userTypeID, 'op' => 'editOp' ]) : route('userTypeOps')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group row">
        <label for="name" class="col-md-4 col-form-label text-md-right">User Type Name</label>
        <div class="col-md-6">
            <input name="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('name') ? old('name') : $name); ?>" required>
            <small class="error"><?php echo e($errors->first('name')); ?></small>
            </div>
          </div>   
        
          <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
            <input value="<?php echo e($modify == 1 ? 'Update' : 'Add'); ?>" name="submit" class="btn btn-success" type="submit">

           
          </div>
          
          </div>
        </form>
<br/>
<br/>

<div class="table-responsive">
<?php echo e($userTypes->onEachSide(5)->links()); ?>

 <table class="table table-striped table-bordered table-hover" width="100%">
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col" >Action</th>
            </tr>
          </thead>
          <tbody>

          <?php $__currentLoopData = $userTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
              <tr>
                <td> <?php echo e($userType->name); ?> </td>
                <td>
                
                <a class="btn btn-success" href="<?php echo e(route('userTypeOps', ['userTypeID' => $userType->id, 'op' => 'edit' ])); ?>">EDIT</a>
                  <a class="btn btn-danger" href="<?php echo e(route('userTypeOps', ['userTypeID' => $userType->id, 'op' => 'delete' ])); ?>">DELETE</a>
                
                  
                </td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              
                      </tbody>
        </table>
        </div>
        </div>
      </div>
    </div> 
     </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\cygwin64\home\u783206\boolean_framework\resources\views/userTypeOps.blade.php ENDPATH**/ ?>