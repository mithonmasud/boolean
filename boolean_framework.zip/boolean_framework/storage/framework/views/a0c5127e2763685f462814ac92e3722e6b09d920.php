<style>
             .content {
                text-align: center;
            }
    
            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none !important;
                text-transform: uppercase;
            }
        
       
        </style>
<?php $__env->startSection('content'); ?>
<div class="container">
  
      
            <div class="card">
                <div class="card-header"><?php echo e(__('About Us')); ?></div>

                <div class="card-body">
               
                <h4>We’re building reliable systems for today and for the future.</h4>
                <p>Boolean company continues to make significant investments to improve the transpotation delivery system – replacing aging facilities and building new ones to meet growth in demand and to make our network even more reliable, resilient and secure.</p>
                <h4>We’re the first in Pennsylvania to give service for all of our customers.</h4>
                <p>Our advanced system enables us to store and manage customer-use data. We are developing ways to use the power of that information to give new options to our customers. We seek to be a trusted counsel to our customers, offering tips and advice to help them learn about and manage their required services use.</p>
               
                </div>
                <div class="card-footer">
                <div class="content">
                <div class="links">
                    <a href="<?php echo e(url('/about')); ?>">About</a>
                    <a href="<?php echo e(url('/contact')); ?>">Contact</a>
                    <a href="<?php echo e(url('/ourGoal')); ?>">Our goal</a>                  
                </div>
                </div>
                </div>
            </div>
     

   
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\cygwin64\home\u783206\boolean_framework\resources\views/others/about.blade.php ENDPATH**/ ?>