<?php echo e($slot); ?>

<?php /**PATH C:\cygwin64\home\u783206\boolean_framework\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>