<style>
             .content {
                text-align: center;
            }
    
            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none !important;
                text-transform: uppercase;
            }
            .title {
                font-size: 25px;
            }
       
        </style>
<?php $__env->startSection('content'); ?>
<div class="container">
   
            <div class="card">
                <div class="card-header"><?php echo e(__('Our Goal')); ?></div>

                <div class="card-body">
                <div class="title m-b-md">
                We are working below applications. We need your opinion!!!.
                </div>
             <br/>
                <h4>Mobile SMS system</h4>
                <p><a href="https://sms.boo-lean.com/" target="_blank" >Ready for Demo</a></p>
                <h4>Tax receipt  apps</h4>
                <p>In prograss...</p>
                <h4>Food Delivery apps - - specific time n urgent</h4>
                <p>In prograss...</p>
                <h4>Online paper</h4>
                <p>In prograss...</p>
                <h4>Office Accounting System</h4>
                <p><a href="https://oas.boo-lean.com/" target="_blank" >Ready for Demo</a></p>
                <h4>Balance due notification of bill payment-Apps</h4>
                <p>In prograss...</p>
                <h4>News paper reading based on your preference-Apps </h4>
                <p>In prograss...</p>
                <h4>Volunteering </h4>  
                <p> 1. We are doing volunteering for tax filing 2018 - FREE. </p>
                <p> 2. Free Medical Clinic.<a href="https://aim.boo-lean.com/contact" target="_blank"> Go to this URL</a>  </p>
                <p> 2. Free Dental Clinic.<a href="https://dental.boo-lean.com/contact" target="_blank"> Go to this URL</a>  </p>

                <h4>Domain and Hosting... </h4>  
                <p> To create your own domain and hosting. Please contact with us <a href="https://boo-lean.com/contact" target="_blank"> Go to this URL</a>  </p>
                </div>
                <div class="card-footer">
                <div class="content">
                <div class="links">
                    <a href="<?php echo e(url('/about')); ?>">About</a>
                    <a href="<?php echo e(url('/contact')); ?>">Contact</a>
                    <a href="<?php echo e(url('/ourGoal')); ?>">Our goal</a>                  
                </div>
            
                </div>
                </div>
       
    </div>

   
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\cygwin64\home\u783206\boolean_framework\resources\views/others/ourGoal.blade.php ENDPATH**/ ?>