<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Users</div>
                <div class="card-body">   
      <?php if( Auth::user()->user_type_id =='1' ): ?>  
      <a class="btn btn-primary" href="<?php echo e(url('/userTypeOps')); ?>">Add User Type</a>                    
        <form action="<?php echo e($modify == 1 ? route('users', [ 'userID' => $userID, 'op' => 'editOp' ]) : route('users')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name') ? old('name') : $name); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email') ? old('email') : $email); ?>" <?php echo e($modify == 1 ? 'readonly' : ''); ?> required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
        <label for="userTypeID" class="col-md-4 col-form-label text-md-right">User Type</label>
        <div class="col-md-6">
          <select name="userTypeID" class="form-control<?php echo e($errors->has('userTypeID') ? ' is-invalid' : ''); ?>" required>
            <option value="">Select One</option>
            <?php $__currentLoopData = $userTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option  value="<?php echo e(old('userTypeID') ? old('userTypeID') :  $userType->id); ?>"
                          <?php if($userType->id == $userTypeID): ?>
                                selected="selected"
                          <?php endif; ?>
                          
                          ><?php echo e($userType->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    
          
            <small class="error"><?php echo e($errors->first('userTypeID')); ?></small>
            
            </div>
          </div>      

                           <div class="form-group row">
                            <label for="phone" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone')); ?></label>

                            <div class="col-md-6">
                                <input id="phone" type="text" class="form-control"  name="phone" value="<?php echo e(old('phone') ? old('phone') : $phone); ?>">

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-8">              
                                <input value="<?php echo e($modify == 1 ? 'Update' : 'Add'); ?>" name="submit" class="btn btn-primary" type="submit">
                            </div>
                        </div>
        </form>
<br/>
<br/>
<div class="table-responsive">
<?php echo e($users->onEachSide(5)->links()); ?>

 <table class="table table-striped table-bordered table-hover" width="100%">
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">User Type</th>
              <th scope="col">Email</th>
              <th scope="col">Phone</th>
              <th scope="col" >Action</th>
            </tr>
          </thead>
          <tbody>

          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($user->id=="1"): ?>
                  <?php continue; ?> 
              <?php endif; ?>    
              <tr>
                <td><?php echo e($user->name); ?></td>                
                <td>
                
                <form action="<?php echo e(route('userTypeUpdate')); ?>" method="post" id="doctor-form<?php echo e($user->id); ?>">

              
                <select name="userTypeID" class="form-control<?php echo e($errors->has('userTypeID') ? ' is-invalid' : ''); ?>" onchange="document.getElementById('doctor-form<?php echo e($user->id); ?>').submit()" required>
            <option value="">Select One</option>
            <?php $__currentLoopData = $userTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option  value="<?php echo e(old('userTypeID') ? old('userTypeID') :  $userType->id); ?>"
                          <?php if($userType->id == $user->user_type_id): ?>
                                selected="selected"
                          <?php endif; ?>
                          
                          ><?php echo e($userType->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    
          
            <small class="error"><?php echo e($errors->first('userTypeID')); ?></small>
            <input  type="hidden"  class="form-control" name="userID"  value="<?php echo e($user->id); ?>" >
            </form>
                </td>
                 <td><?php echo e($user->email); ?> </td>
                 <td><?php echo e($user->phone); ?> </td>
                <td>
                
                <a class="btn btn-success" href="<?php echo e(route('users', ['userID' => $user->id, 'op' => 'edit' ])); ?>">EDIT</a>
                  <a class="btn btn-danger" href="<?php echo e(route('users', ['userID' => $user->id, 'op' => 'delete' ])); ?>">DELETE</a>
                
                  
                </td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              
                      </tbody>
        </table>
        </div>
       
     
<?php endif; ?>






                </div>
            </div>
        </div>
    </div>
</div>
 
<script src="<?php echo e(asset('js/css/js/jquery-1.10.2.js')); ?>" defer></script>
 <script src="<?php echo e(asset('js/css/js/jquery-ui.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\cygwin64\home\u783206\boolean_framework\resources\views/users.blade.php ENDPATH**/ ?>