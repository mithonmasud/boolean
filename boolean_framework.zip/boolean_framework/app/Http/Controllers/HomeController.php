<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\UserType;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(UserType $userType,User $user)
    {
        $this->middleware('auth');
        $this->user = $user; 
        $this->userType = $userType; 
        $now =new \DateTime();
        $this->currentTime = $now->format('Y-m-d H:i:s');        
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    
    public function userAction(Request $request)
    {
        $data = [];
        $data['modify'] = 0;        
        $data['userID'] = 0;
        $data['userTypeID'] = 0;
        $data['name'] = "";
        $data['email'] = "";
        $data['phone'] = "";
        $data['password'] = "";
        if( $request->isMethod('get') )
        {
            $op =  $request->input('op');
            $data['userID']  =  $request->input('userID');
            if($op=="edit")
            {
                $doc = $this->user->find($data['userID']);             
                $data['name'] = $doc->name;
                $data['email'] = $doc->email;
                $data['phone'] = $doc->phone;
                $data['userTypeID'] = $doc->user_type_id;
                $data['modify'] = 1;
            }
            else if($op=="delete")
            {
                $doc = $this->user->find($data['userID']);          
                $doc->delete();
            }
        }       

        if( $request->isMethod('post') )
        {           
          $submit =  $request->input('submit');       
          if($submit=="Add")
          {
           // dd($request); exit;
            $this->validate(
              $request,
              [
                'name' => ['required', 'string', 'max:50'],
                'email' => ['required', 'string', 'email', 'max:50', 'unique:users'],
                'password' => ['required', 'string', 'min:8', 'confirmed'],
                'userTypeID' => ['required'],
              ]
          );

             $projectObj['name'] =  $request->input('name');
            $projectObj['email'] =  $request->input('email');
            $projectObj['phone'] =  $request->input('phone');
            $projectObj['user_type_id'] =  $request->input('userTypeID');
            $projectObj['password'] =  Hash::make($request->input('password'));
            $projectObj['created_at'] =  $this->currentTime;
            $projectObj['created_by'] =  Auth::user()->id;
            //dd($projectObj); exit;
            $this->user->insert($projectObj);
          }
          else if($submit=="Update")
          {

            $this->validate(
              $request,
              [
                'name' => ['required', 'string', 'max:50'],
                'email' => ['required', 'string', 'email', 'max:50'],
                'password' => ['required', 'string', 'min:8', 'confirmed'],
                'userTypeID' => ['required'],
              ]
          );

            $data['userID']  =  $request->input('userID');
            $project_data = $this->user->find($data['userID']);
            $project_data->name =  $request->input('name');
            $project_data->email =  $request->input('email');
            $project_data->phone =  $request->input('phone');
            $project_data->user_type_id =  $request->input('userTypeID');
            $project_data->password = Hash::make($request->input('password'));
            $project_data->updated_by = Auth::user()->id;
            $project_data->updated_at = $this->currentTime;	
            $project_data->save();
          }
        }
        $data['users'] = $this->user->getAll();
        $data['userTypes'] = $this->userType->all();
        return view('users', $data);
    }

    public function userTypeOps(Request $request)
    {
        $data = [];
        $data['modify'] = 0;        
        $data['userTypeID'] = 0;
        $data['name'] = "";
        if( $request->isMethod('get') )
        {
            $op =  $request->input('op');
            $data['userTypeID']  =  $request->input('userTypeID');
            if($op=="edit")
            {
                $doc = $this->userType->find($data['userTypeID']);             
                $data['name'] = $doc->name;
                $data['modify'] = 1;
            }
            else if($op=="delete")
            {
                $doc = $this->userType->find($data['userTypeID']);          
                $doc->delete();
            }
        }       

        if( $request->isMethod('post') )
        {
          $submit =  $request->input('submit');
          if($submit=="Add")
          {
            $serviceObj['name'] =  $request->input('name');
            $serviceObj['created_at'] =  $this->currentTime;
            $serviceObj['created_by'] =  Auth::user()->id;
            $this->userType->insert($serviceObj);
          }
          else if($submit=="Update")
          {
            $data['userTypeID']  =  $request->input('userTypeID');
            $service_data = $this->userType->find($data['userTypeID']);
            $service_data->name =  $request->input('name');
            $service_data->updated_by = Auth::user()->id;	
            $service_data->save();
          }
        }
        $data['userTypes'] = $this->userType->getAll();
        return view('userTypeOps', $data);
    }

    public function userTypeUpdate(Request $request)
    {
        if( $request->isMethod('post') )
        {
            $data['userID']  =  $request->input('userID');
            $service_data = $this->user->find($data['userID']);
            $service_data->user_type_id =  $request->input('userTypeID');
            $service_data->updated_at = $this->currentTime;
            $service_data->updated_by = Auth::user()->id;	
            $service_data->save();
        }
        return $this->userAction($request);
    }

}
