<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class UserType extends Model
{
    //
  function getAll()
  {
    $user_types = DB::table('user_types')
    ->orderBy('created_at', 'desc')
    ->paginate(10);
    return $user_types;
  }
}
