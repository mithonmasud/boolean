<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Stripe, Mailgun, SparkPost and others. This file provides a sane
    | default location for this type of information, allowing packages
    | to have a conventional place to find your various credentials.
    |
    */

    'mailgun' => [
        'domain' => env('sandbox727b2c47ced948c9876641956c6b7495.mailgun.org'),
        'secret' => env('pubkey-89d7973db40cd11705f7c9ae54f10d62'),
        'endpoint' => env('https://api.mailgun.net/v3/sandbox727b2c47ced948c9876641956c6b7495.mailgun.org', 'api.mailgun.net'),
    ],

    
];
