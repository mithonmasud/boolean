@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
        
        <div class="card-header">{{ $modify == 1 ? 'Modify User Type' : 'User Type Information' }}</div>
        <div class="card-body">
        <a class="btn btn-primary" href="{{ url('/users') }}">Back</a>     
        <form action="{{ $modify == 1 ? route('userTypeOps', [ 'userTypeID' => $userTypeID, 'op' => 'editOp' ]) : route('userTypeOps') }}" method="post">
        @csrf
        <div class="form-group row">
        <label for="name" class="col-md-4 col-form-label text-md-right">User Type Name</label>
        <div class="col-md-6">
            <input name="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" value="{{ old('name') ? old('name') : $name }}" required>
            <small class="error">{{$errors->first('name')}}</small>
            </div>
          </div>   
        
          <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
            <input value="{{ $modify == 1 ? 'Update' : 'Add' }}" name="submit" class="btn btn-success" type="submit">

           
          </div>
          
          </div>
        </form>
<br/>
<br/>

<div class="table-responsive">
{{ $userTypes->onEachSide(5)->links() }}
 <table class="table table-striped table-bordered table-hover" width="100%">
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col" >Action</th>
            </tr>
          </thead>
          <tbody>

          @foreach( $userTypes as $userType )
          
              <tr>
                <td> {{ $userType->name }} </td>
                <td>
                
                <a class="btn btn-success" href="{{ route('userTypeOps', ['userTypeID' => $userType->id, 'op' => 'edit' ]) }}">EDIT</a>
                  <a class="btn btn-danger" href="{{ route('userTypeOps', ['userTypeID' => $userType->id, 'op' => 'delete' ]) }}">DELETE</a>
                
                  
                </td>
              </tr>
          @endforeach

              
                      </tbody>
        </table>
        </div>
        </div>
      </div>
    </div> 
     </div>
    </div>
@endsection