@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Users</div>
                <div class="card-body">   
      @if( Auth::user()->user_type_id =='1' )  
      <a class="btn btn-primary" href="{{ url('/userTypeOps') }}">Add User Type</a>                    
        <form action="{{ $modify == 1 ? route('users', [ 'userID' => $userID, 'op' => 'editOp' ]) : route('users') }}" method="post">
        @csrf
        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name') ? old('name') : $name }}" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') ? old('email') : $email }}" {{ $modify == 1 ? 'readonly' : '' }} required>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
        <label for="userTypeID" class="col-md-4 col-form-label text-md-right">User Type</label>
        <div class="col-md-6">
          <select name="userTypeID" class="form-control{{ $errors->has('userTypeID') ? ' is-invalid' : '' }}" required>
            <option value="">Select One</option>
            @foreach( $userTypes as $userType )
                          <option  value="{{ old('userTypeID') ? old('userTypeID') :  $userType->id  }}"
                          @if ($userType->id == $userTypeID)
                                selected="selected"
                          @endif
                          
                          >{{ $userType->name }}</option>
            @endforeach
                        </select>
                    
          
            <small class="error">{{$errors->first('userTypeID')}}</small>
            
            </div>
          </div>      

                           <div class="form-group row">
                            <label for="phone" class="col-md-4 col-form-label text-md-right">{{ __('Phone') }}</label>

                            <div class="col-md-6">
                                <input id="phone" type="text" class="form-control"  name="phone" value="{{ old('phone') ? old('phone') : $phone }}">

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-8">              
                                <input value="{{ $modify == 1 ? 'Update' : 'Add' }}" name="submit" class="btn btn-primary" type="submit">
                            </div>
                        </div>
        </form>
<br/>
<br/>
<div class="table-responsive">
{{ $users->onEachSide(5)->links() }}
 <table class="table table-striped table-bordered table-hover" width="100%">
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">User Type</th>
              <th scope="col">Email</th>
              <th scope="col">Phone</th>
              <th scope="col" >Action</th>
            </tr>
          </thead>
          <tbody>

          @foreach( $users as $user )
              @if($user->id=="1")
                  @continue 
              @endif    
              <tr>
                <td>{{ $user->name }}</td>                
                <td>
                
                <form action="{{ route('userTypeUpdate') }}" method="post" id="doctor-form{{ $user->id}}">

              
                <select name="userTypeID" class="form-control{{ $errors->has('userTypeID') ? ' is-invalid' : '' }}" onchange="document.getElementById('doctor-form{{ $user->id}}').submit()" required>
            <option value="">Select One</option>
            @foreach( $userTypes as $userType )
                          <option  value="{{ old('userTypeID') ? old('userTypeID') :  $userType->id  }}"
                          @if ($userType->id == $user->user_type_id)
                                selected="selected"
                          @endif
                          
                          >{{ $userType->name }}</option>
            @endforeach
                        </select>
                    
          
            <small class="error">{{$errors->first('userTypeID')}}</small>
            <input  type="hidden"  class="form-control" name="userID"  value="{{ $user->id }}" >
            </form>
                </td>
                 <td>{{ $user->email }} </td>
                 <td>{{ $user->phone }} </td>
                <td>
                
                <a class="btn btn-success" href="{{ route('users', ['userID' => $user->id, 'op' => 'edit' ]) }}">EDIT</a>
                  <a class="btn btn-danger" href="{{ route('users', ['userID' => $user->id, 'op' => 'delete' ]) }}">DELETE</a>
                
                  
                </td>
              </tr>
          @endforeach

              
                      </tbody>
        </table>
        </div>
       
     
@endif






                </div>
            </div>
        </div>
    </div>
</div>
 
<script src="{{ asset('js/css/js/jquery-1.10.2.js') }}" defer></script>
 <script src="{{ asset('js/css/js/jquery-ui.js') }}" defer></script>
@endsection
