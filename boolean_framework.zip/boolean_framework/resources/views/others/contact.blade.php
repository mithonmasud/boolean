@extends('layouts.app')
<style>
             .content {
                text-align: center;
            }
    
            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none !important;
                text-transform: uppercase;
            }
            .title {
                font-size: 35px;
            }
       
        </style>
@section('content')
<div class="container">
   
            <div class="card">
                <div class="card-header">{{ __('Contact Us') }}</div>

                <div class="card-body">
                <div class="title m-b-md">
                HOW TO REACH BOO
                </div>
                <h4>Small Business</h4>
                <p>+1717-982-0481</p>
                <h4>Mid- and Large Business</h4>
                <p>+1717-982-0481</p>               
                </div>
                <div class="card-footer">
                <div class="content">
                <div class="links">
                    <a href="{{ url('/about') }}">About</a>
                    <a href="{{ url('/contact') }}">Contact</a>
                    <a href="{{ url('/ourGoal') }}">Our goal</a>                  
                </div>
                </div>
                </div>
         
    </div>

   
</div>
@endsection
